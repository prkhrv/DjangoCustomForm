from django import forms
from register.models import UserProfile

class Registration(forms.ModelForm):
    class Meta():
        model = UserProfile
        fields = ( 'name',
                   'branch',
                   'section',
                   'year',
                   'roll',
                   'email',
                   'Phone',

        )
