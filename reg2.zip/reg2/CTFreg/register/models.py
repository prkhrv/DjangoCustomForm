from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    name = models.CharField(max_length=100,default='')
    branch = models.CharField(max_length=100,default='')
    section = models.CharField(max_length=100,default='')
    year = models.IntegerField(default=0)
    roll = models.IntegerField(default=0)
    email = models.EmailField(max_length=100,default='')
    Phone = models.IntegerField(default=0)
