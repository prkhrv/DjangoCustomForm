from django.shortcuts import render
from register.forms import Registration
from django.core.mail import send_mail
# Create your views here.
def index(request):
    return render(request,'register/index.html')

def form_name_view(request):


    form = Registration()

    if(request.method=='POST'):
        form = Registration(request.POST)

        if(form.is_valid()):
            form.save(commit=True)
            to_email = form.cleaned_data.get('email')
            send_mail('Thanks for Registration',
            'Please wait for The confirmation mail, For further query please contact :-9568585828',
            'noreply@codeavengers.tech',
            [to_email],
            fail_silently=False,)
            return index(request)
        else:
            print('FORM IS INVALID')
    return render(request,'register/form_page.html')
