from django.contrib import admin
from register.models import UserProfile

# Register your models here.
admin.site.register(UserProfile)
